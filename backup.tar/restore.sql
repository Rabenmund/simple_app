--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_matchdays_on_number;
DROP INDEX public.index_games_on_home_id;
DROP INDEX public.index_games_on_guest_id;
ALTER TABLE ONLY public.teams DROP CONSTRAINT teams_pkey;
ALTER TABLE ONLY public.seasons DROP CONSTRAINT seasons_pkey;
ALTER TABLE ONLY public.results DROP CONSTRAINT results_pkey;
ALTER TABLE ONLY public.points DROP CONSTRAINT points_pkey;
ALTER TABLE ONLY public.matchdays DROP CONSTRAINT matchdays_pkey;
ALTER TABLE ONLY public.games DROP CONSTRAINT games_pkey;
ALTER TABLE ONLY public.federations DROP CONSTRAINT federations_pkey;
ALTER TABLE ONLY public.draws DROP CONSTRAINT draws_pkey;
ALTER TABLE ONLY public.competitions_teams DROP CONSTRAINT competitions_teams_pkey;
ALTER TABLE ONLY public.competitions DROP CONSTRAINT competitions_pkey;
ALTER TABLE ONLY public.appointments DROP CONSTRAINT appointments_pkey;
ALTER TABLE public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.seasons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.results ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.points ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.matchdays ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.games ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.federations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.draws ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.competitions_teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.competitions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.appointments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.teams_id_seq;
DROP TABLE public.teams;
DROP SEQUENCE public.seasons_id_seq;
DROP TABLE public.seasons;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.results_id_seq;
DROP TABLE public.results;
DROP SEQUENCE public.points_id_seq;
DROP TABLE public.points;
DROP SEQUENCE public.matchdays_id_seq;
DROP TABLE public.matchdays;
DROP SEQUENCE public.games_id_seq;
DROP TABLE public.games;
DROP TABLE public.federations_seasons;
DROP SEQUENCE public.federations_id_seq;
DROP TABLE public.federations;
DROP SEQUENCE public.draws_id_seq;
DROP TABLE public.draws;
DROP SEQUENCE public.competitions_teams_id_seq;
DROP TABLE public.competitions_teams;
DROP SEQUENCE public.competitions_id_seq;
DROP TABLE public.competitions;
DROP SEQUENCE public.appointments_id_seq;
DROP TABLE public.appointments;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dwiedenbruch
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO dwiedenbruch;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: dwiedenbruch
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE appointments (
    id integer NOT NULL,
    appointable_id integer NOT NULL,
    appointable_type character varying(255) NOT NULL,
    competition_id integer,
    appointed_at timestamp without time zone NOT NULL
);


ALTER TABLE public.appointments OWNER TO dwiedenbruch;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE appointments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointments_id_seq OWNER TO dwiedenbruch;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE appointments_id_seq OWNED BY appointments.id;


--
-- Name: competitions; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE competitions (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    level integer,
    federation_id integer,
    season_id integer,
    start timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.competitions OWNER TO dwiedenbruch;

--
-- Name: competitions_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE competitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.competitions_id_seq OWNER TO dwiedenbruch;

--
-- Name: competitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE competitions_id_seq OWNED BY competitions.id;


--
-- Name: competitions_teams; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE competitions_teams (
    id integer NOT NULL,
    competition_id integer,
    team_id integer
);


ALTER TABLE public.competitions_teams OWNER TO dwiedenbruch;

--
-- Name: competitions_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE competitions_teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.competitions_teams_id_seq OWNER TO dwiedenbruch;

--
-- Name: competitions_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE competitions_teams_id_seq OWNED BY competitions_teams.id;


--
-- Name: draws; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE draws (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    performed_at timestamp without time zone,
    finished boolean DEFAULT false,
    cup_id integer,
    matchday_id integer
);


ALTER TABLE public.draws OWNER TO dwiedenbruch;

--
-- Name: draws_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE draws_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.draws_id_seq OWNER TO dwiedenbruch;

--
-- Name: draws_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE draws_id_seq OWNED BY draws.id;


--
-- Name: federations; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE federations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.federations OWNER TO dwiedenbruch;

--
-- Name: federations_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE federations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.federations_id_seq OWNER TO dwiedenbruch;

--
-- Name: federations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE federations_id_seq OWNED BY federations.id;


--
-- Name: federations_seasons; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE federations_seasons (
    federation_id integer,
    season_id integer
);


ALTER TABLE public.federations_seasons OWNER TO dwiedenbruch;

--
-- Name: games; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE games (
    id integer NOT NULL,
    home_id integer NOT NULL,
    guest_id integer NOT NULL,
    home_goals integer,
    guest_goals integer,
    home_half_goals integer,
    guest_half_goals integer,
    home_full_goals integer,
    guest_full_goals integer,
    home_xtra_half_goals integer,
    guest_xtra_half_goals integer,
    home_xtra_full_goals integer,
    guest_xtra_full_goals integer,
    half_second integer,
    full_second integer,
    xtra_half_second integer,
    xtra_full_second integer,
    second integer DEFAULT 0,
    level integer,
    performed_at timestamp without time zone,
    decision boolean DEFAULT false,
    finished boolean DEFAULT false,
    matchday_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.games OWNER TO dwiedenbruch;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE games_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_id_seq OWNER TO dwiedenbruch;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE games_id_seq OWNED BY games.id;


--
-- Name: matchdays; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE matchdays (
    id integer NOT NULL,
    number integer NOT NULL,
    start timestamp without time zone NOT NULL,
    competition_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.matchdays OWNER TO dwiedenbruch;

--
-- Name: matchdays_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE matchdays_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.matchdays_id_seq OWNER TO dwiedenbruch;

--
-- Name: matchdays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE matchdays_id_seq OWNED BY matchdays.id;


--
-- Name: points; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE points (
    id integer NOT NULL,
    points integer,
    goals integer,
    against integer,
    diff integer,
    win integer,
    draw integer,
    lost integer,
    level integer,
    game_id integer NOT NULL,
    team_id integer NOT NULL,
    league_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.points OWNER TO dwiedenbruch;

--
-- Name: points_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.points_id_seq OWNER TO dwiedenbruch;

--
-- Name: points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE points_id_seq OWNED BY points.id;


--
-- Name: results; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE results (
    id integer NOT NULL,
    points integer DEFAULT 0,
    goals integer DEFAULT 0,
    against integer DEFAULT 0,
    diff integer DEFAULT 0,
    win integer DEFAULT 0,
    draw integer DEFAULT 0,
    lost integer DEFAULT 0,
    team_id integer NOT NULL,
    league_id integer NOT NULL,
    level integer,
    year integer,
    rank integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.results OWNER TO dwiedenbruch;

--
-- Name: results_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE results_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.results_id_seq OWNER TO dwiedenbruch;

--
-- Name: results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE results_id_seq OWNED BY results.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO dwiedenbruch;

--
-- Name: seasons; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE seasons (
    id integer NOT NULL,
    year integer NOT NULL,
    start timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.seasons OWNER TO dwiedenbruch;

--
-- Name: seasons_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE seasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seasons_id_seq OWNER TO dwiedenbruch;

--
-- Name: seasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE seasons_id_seq OWNED BY seasons.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE TABLE teams (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    short_name character varying(255) NOT NULL,
    abbreviation character varying(255) NOT NULL,
    federation_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.teams OWNER TO dwiedenbruch;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: dwiedenbruch
--

CREATE SEQUENCE teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO dwiedenbruch;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dwiedenbruch
--

ALTER SEQUENCE teams_id_seq OWNED BY teams.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY appointments ALTER COLUMN id SET DEFAULT nextval('appointments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY competitions ALTER COLUMN id SET DEFAULT nextval('competitions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY competitions_teams ALTER COLUMN id SET DEFAULT nextval('competitions_teams_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY draws ALTER COLUMN id SET DEFAULT nextval('draws_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY federations ALTER COLUMN id SET DEFAULT nextval('federations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY games ALTER COLUMN id SET DEFAULT nextval('games_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY matchdays ALTER COLUMN id SET DEFAULT nextval('matchdays_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY points ALTER COLUMN id SET DEFAULT nextval('points_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY results ALTER COLUMN id SET DEFAULT nextval('results_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY seasons ALTER COLUMN id SET DEFAULT nextval('seasons_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dwiedenbruch
--

ALTER TABLE ONLY teams ALTER COLUMN id SET DEFAULT nextval('teams_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY appointments (id, appointable_id, appointable_type, competition_id, appointed_at) FROM stdin;
\.
COPY appointments (id, appointable_id, appointable_type, competition_id, appointed_at) FROM '$$PATH$$/2314.dat';

--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('appointments_id_seq', 369, true);


--
-- Data for Name: competitions; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY competitions (id, name, type, level, federation_id, season_id, start, created_at, updated_at) FROM stdin;
\.
COPY competitions (id, name, type, level, federation_id, season_id, start, created_at, updated_at) FROM '$$PATH$$/2316.dat';

--
-- Name: competitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('competitions_id_seq', 8, true);


--
-- Data for Name: competitions_teams; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY competitions_teams (id, competition_id, team_id) FROM stdin;
\.
COPY competitions_teams (id, competition_id, team_id) FROM '$$PATH$$/2318.dat';

--
-- Name: competitions_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('competitions_teams_id_seq', 126, true);


--
-- Data for Name: draws; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY draws (id, name, performed_at, finished, cup_id, matchday_id) FROM stdin;
\.
COPY draws (id, name, performed_at, finished, cup_id, matchday_id) FROM '$$PATH$$/2320.dat';

--
-- Name: draws_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('draws_id_seq', 1, false);


--
-- Data for Name: federations; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY federations (id, name, created_at, updated_at) FROM stdin;
\.
COPY federations (id, name, created_at, updated_at) FROM '$$PATH$$/2322.dat';

--
-- Name: federations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('federations_id_seq', 1, true);


--
-- Data for Name: federations_seasons; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY federations_seasons (federation_id, season_id) FROM stdin;
\.
COPY federations_seasons (federation_id, season_id) FROM '$$PATH$$/2324.dat';

--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY games (id, home_id, guest_id, home_goals, guest_goals, home_half_goals, guest_half_goals, home_full_goals, guest_full_goals, home_xtra_half_goals, guest_xtra_half_goals, home_xtra_full_goals, guest_xtra_full_goals, half_second, full_second, xtra_half_second, xtra_full_second, second, level, performed_at, decision, finished, matchday_id, created_at, updated_at) FROM stdin;
\.
COPY games (id, home_id, guest_id, home_goals, guest_goals, home_half_goals, guest_half_goals, home_full_goals, guest_full_goals, home_xtra_half_goals, guest_xtra_half_goals, home_xtra_full_goals, guest_xtra_full_goals, half_second, full_second, xtra_half_second, xtra_full_second, second, level, performed_at, decision, finished, matchday_id, created_at, updated_at) FROM '$$PATH$$/2325.dat';

--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('games_id_seq', 369, true);


--
-- Data for Name: matchdays; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY matchdays (id, number, start, competition_id, created_at, updated_at) FROM stdin;
\.
COPY matchdays (id, number, start, competition_id, created_at, updated_at) FROM '$$PATH$$/2327.dat';

--
-- Name: matchdays_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('matchdays_id_seq', 40, true);


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY points (id, points, goals, against, diff, win, draw, lost, level, game_id, team_id, league_id, created_at, updated_at) FROM stdin;
\.
COPY points (id, points, goals, against, diff, win, draw, lost, level, game_id, team_id, league_id, created_at, updated_at) FROM '$$PATH$$/2329.dat';

--
-- Name: points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('points_id_seq', 1, false);


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY results (id, points, goals, against, diff, win, draw, lost, team_id, league_id, level, year, rank, created_at, updated_at) FROM stdin;
\.
COPY results (id, points, goals, against, diff, win, draw, lost, team_id, league_id, level, year, rank, created_at, updated_at) FROM '$$PATH$$/2331.dat';

--
-- Name: results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('results_id_seq', 126, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2333.dat';

--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY seasons (id, year, start, created_at, updated_at) FROM stdin;
\.
COPY seasons (id, year, start, created_at, updated_at) FROM '$$PATH$$/2334.dat';

--
-- Name: seasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('seasons_id_seq', 1, true);


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: dwiedenbruch
--

COPY teams (id, name, short_name, abbreviation, federation_id, created_at, updated_at) FROM stdin;
\.
COPY teams (id, name, short_name, abbreviation, federation_id, created_at, updated_at) FROM '$$PATH$$/2336.dat';

--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dwiedenbruch
--

SELECT pg_catalog.setval('teams_id_seq', 126, true);


--
-- Name: appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: competitions_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY competitions
    ADD CONSTRAINT competitions_pkey PRIMARY KEY (id);


--
-- Name: competitions_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY competitions_teams
    ADD CONSTRAINT competitions_teams_pkey PRIMARY KEY (id);


--
-- Name: draws_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY draws
    ADD CONSTRAINT draws_pkey PRIMARY KEY (id);


--
-- Name: federations_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY federations
    ADD CONSTRAINT federations_pkey PRIMARY KEY (id);


--
-- Name: games_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: matchdays_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY matchdays
    ADD CONSTRAINT matchdays_pkey PRIMARY KEY (id);


--
-- Name: points_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY points
    ADD CONSTRAINT points_pkey PRIMARY KEY (id);


--
-- Name: results_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: seasons_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: teams_pkey; Type: CONSTRAINT; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

ALTER TABLE ONLY teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: index_games_on_guest_id; Type: INDEX; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE INDEX index_games_on_guest_id ON games USING btree (guest_id);


--
-- Name: index_games_on_home_id; Type: INDEX; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE INDEX index_games_on_home_id ON games USING btree (home_id);


--
-- Name: index_matchdays_on_number; Type: INDEX; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE INDEX index_matchdays_on_number ON matchdays USING btree (number);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: dwiedenbruch; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: dwiedenbruch
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM dwiedenbruch;
GRANT ALL ON SCHEMA public TO dwiedenbruch;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

